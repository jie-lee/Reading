# 肠道菌群论文数据分析复现之——对fastq文件进行质控3

#zless 查看压缩文件

`zless SRR11123357.fastq.gz |head -n 8`

#md5sum 通过md5校验下载内容是否完整

##md5sum是shell命令用于校验MD5校验码

`md5sum *gz >md5.txt`

`md5sum -c md5.txt`

#Linux wc命令用于计算字数。

`ls |wc -l`

#安装fastqc

`conda install -c bioconda/label/cf201901 fastqc`

![Untitled](%E8%82%A0%E9%81%93%E8%8F%8C%E7%BE%A4%E8%AE%BA%E6%96%87%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90%E5%A4%8D%E7%8E%B0%E4%B9%8B%E2%80%94%E2%80%94%E5%AF%B9fastq%E6%96%87%E4%BB%B6%E8%BF%9B%E8%A1%8C%E8%B4%A8%E6%8E%A73%20f32f3c0fadeb46a39eba0decf4ae028c/Untitled.png)

#先使用管道批量fastqc

`ls *gz |xargs fastqc -t 2`

#安装multiqc

`conda install -c bioconda multiqc`

#汇总质控

`multiqc ./`

---

**##此处出现意外，版本不匹配，可创建虚拟环境解决**

`conda create --name bioenv`

##激活bioenv

`conda activate bioenv`

##deactivate

`conda deactivate`

#查看存在哪些虚拟环境

`conda env list` 

`conda info -e`

#删除虚拟环境

`conda remove -n your_env_na从打me --all`

#导出虚拟环境

`conda env export > environment.yaml`

#复现虚拟环境

`conda env create -f environment.yaml`

---

##安装：`trim-galore`质控软件

`conda install -c bioconda trim-galore`

[质控报告解读](%E8%82%A0%E9%81%93%E8%8F%8C%E7%BE%A4%E8%AE%BA%E6%96%87%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90%E5%A4%8D%E7%8E%B0%E4%B9%8B%E2%80%94%E2%80%94%E5%AF%B9fastq%E6%96%87%E4%BB%B6%E8%BF%9B%E8%A1%8C%E8%B4%A8%E6%8E%A73%20f32f3c0fadeb46a39eba0decf4ae028c/%E8%B4%A8%E6%8E%A7%E6%8A%A5%E5%91%8A%E8%A7%A3%E8%AF%BB%203d8768d8223446eaa0111165e3cb2599.md)